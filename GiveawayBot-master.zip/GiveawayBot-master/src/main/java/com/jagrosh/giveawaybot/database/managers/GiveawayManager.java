/*
 * Copyright 2017 John Grosh (john.a.grosh@gmail.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jagrosh.giveawaybot.database.managers;

import com.jagrosh.easysql.DataManager;
import com.jagrosh.easysql.SQLColumn;
import com.jagrosh.easysql.columns.*;
import com.jagrosh.giveawaybot.database.Database;
import com.jagrosh.giveawaybot.entities.Giveaway;
import com.jagrosh.giveawaybot.entities.Status;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.LinkedList;
import java.util.List;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.entities.User;

/**
 *
 * @author John Grosh (john.a.grosh@gmail.com)
 */
public class GiveawayManager extends DataManager
{
    public final static SQLColumn<Long>    GUILD_ID    = new LongColumn   ("GUILD_ID",    false, 0L);
    public final static SQLColumn<Long>    CHANNEL_ID  = new LongColumn   ("CHANNEL_ID",  false, 0L);
    public final static SQLColumn<Long>    MESSAGE_ID  = new LongColumn   ("MESSAGE_ID",  false, 0L, true);
    public final static SQLColumn<Instant> END_TIME    = new InstantColumn("END_TIME",    false, Instant.MIN);
    public final static SQLColumn<Integer> NUM_WINNERS = new IntegerColumn("NUM_WINNERS", false, 1);
    public final static SQLColumn<String>  PRIZE       = new StringColumn ("PRIZE",       true,  null, 250);
    public final static SQLColumn<Integer> STATUS      = new IntegerColumn("STATUS",      false, Status.RUN.ordinal());
    public final static SQLColumn<Long>    USER_ID     = new LongColumn   ("USER_ID",     false, 0L);
    public final static SQLColumn<Boolean> EXPANDED    = new BooleanColumn("EXPANDED",    false, false);
    
    public GiveawayManager(Database connector)
    {
        super(connector, "GIVEAWAYS");
    }
    
    public Giveaway getGiveaway(long messageId, long guildId)
    {
        return read(selectAll(MESSAGE_ID.is(messageId)), results -> 
        {
            if(results.next() && GUILD_ID.getValue(results)==guildId)
                return giveaway(results);
            return null;
        });
    }
    
    public List<Giveaway> getGiveaways()
    {
        return getGiveaways(selectAll());
    }
    
    public List<Giveaway> getGiveaways(TextChannel channel)
    {
        return getGiveaways(selectAll(CHANNEL_ID.is(channel.getIdLong())));
    }
    
    public List<Giveaway> getGiveaways(Guild guild)
    {
        return getGiveaways(selectAll(GUILD_ID.is(guild.getIdLong())));
    }
    
    public List<Giveaway> getGiveaways(Status status)
    {
        return getGiveaways(selectAll(STATUS.is(status.ordinal())));
    }
    
    private List<Giveaway> getGiveaways(String selection)
    {
        return read(selection, results -> 
        {
            List<Giveaway> list = new LinkedList<>();
            while(results.next())
                list.add(giveaway(results));
            return list;
        }, null);
    }
    
    public List<Giveaway> getGiveawaysEndingBefore(Instant end)
    {
        return getGiveaways(selectAll(END_TIME.isLessThan(end.getEpochSecond()) + " AND " + STATUS.is(Status.RUN.ordinal())));
    }
    
    public boolean createGiveaway(Message message, User creator, Instant end, int winners, String prize, boolean expanded)
    {
        return createGiveaway(message.getGuild().getIdLong(), message.getTextChannel().getIdLong(), message.getIdLong(), creator.getIdLong(), end, winners, prize, expanded);
    }
    
    public boolean createGiveaway(long guildid, long channelid, long messageid, long userid, Instant end, int winners, String prize, boolean expanded)
    {
        return readWrite(selectAll(MESSAGE_ID.is(messageid)), results -> 
        {
            if(results.next())
            {
                GUILD_ID.updateValue(results, guildid);
                CHANNEL_ID.updateValue(results, channelid);
                MESSAGE_ID.updateValue(results, messageid);
                USER_ID.updateValue(results, userid);
                END_TIME.updateValue(results, end);
                NUM_WINNERS.updateValue(results, winners);
                PRIZE.updateValue(results, prize);
                STATUS.updateValue(results, Status.RUN.ordinal());
                EXPANDED.updateValue(results, expanded);
                results.updateRow();
                return true;
            }
            else
            {
                results.moveToInsertRow();
                GUILD_ID.updateValue(results, guildid);
                CHANNEL_ID.updateValue(results, channelid);
                MESSAGE_ID.updateValue(results, messageid);
                USER_ID.updateValue(results, userid);
                END_TIME.updateValue(results, end);
                NUM_WINNERS.updateValue(results, winners);
                PRIZE.updateValue(results, prize);
                STATUS.updateValue(results, Status.RUN.ordinal());
                EXPANDED.updateValue(results, expanded);
                results.insertRow();
                return true;
            }
        }, false);
    }
    
    public boolean deleteGiveaway(long messageId)
    {
        return readWrite(selectAll(MESSAGE_ID.is(messageId)), results -> 
        {
            if(results.next())
            {
                results.deleteRow();
                return true;
            }
            else
                return true;
        }, false);
    }
    
    public boolean setStatus(long messageId, Status status)
    {
        return readWrite(selectAll(MESSAGE_ID.is(messageId)), results -> 
        {
            if(results.next())
            {
                STATUS.updateValue(results, status.ordinal());
                results.updateRow();
                return true;
            }
            else
                return false;
        }, false);
    }
    
    private static Giveaway giveaway(ResultSet results) throws SQLException
    {
        return new Giveaway(MESSAGE_ID.getValue(results), CHANNEL_ID.getValue(results), GUILD_ID.getValue(results), USER_ID.getValue(results),
                END_TIME.getValue(results), NUM_WINNERS.getValue(results), PRIZE.getValue(results), Status.values()[STATUS.getValue(results)], 
                EXPANDED.getValue(results));
    }
}
